package es.unican.is2.modelo;

public interface TimedState {
	
	public void timeout(Alarmas context);
	
}
